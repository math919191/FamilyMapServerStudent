package Model.Data;

public class SNamesData extends NamesData {
    SNamesData(){
        super();
    }
}
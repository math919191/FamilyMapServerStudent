package Model.Data;

public class MNamesData extends NamesData {
    MNamesData(){
        super();
    }
}

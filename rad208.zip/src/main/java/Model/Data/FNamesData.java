package Model.Data;


public class FNamesData extends NamesData {
    FNamesData(){
        super();
    }
}
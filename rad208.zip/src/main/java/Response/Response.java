package Response;
    /** Parent response object */
public class Response {
    /** Message of the response */
    String message;
    /** says whether the response was successful or not */
    boolean success;


}
